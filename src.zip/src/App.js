import React, { useState, useEffect } from 'react';
import axios from 'axios';

// Cambiamos 'clientes' por 'persona'
const API_URL = "http://localhost:8080/api/persona";
function App() {
    const [clientes, setClientes] = useState([]);
    const [nombre, setNombre] = useState('');

    const cargarDatos = async () => {
        try {
            const res = await axios.get(API_URL);
            const datosCorrectos = Array.isArray(res.data) ? res.data : (res.data.$values || []);
            setClientes(datosCorrectos);
        } catch (err) {
            console.error("Error de conexión", err);
        }
    };

    useEffect(() => { cargarDatos(); }, []);

    const guardar = async () => {
        if (!nombre) return;
        try {
            await axios.post(API_URL, { Nombre: nombre });
            setNombre('');
            setTimeout(() => { cargarDatos(); }, 700);
        } catch (err) {
            alert("Error al guardar. Revisa que el contenedor de Docker esté UP.");
        }
    };

    const eliminar = async (id) => {
        try {
            await axios.delete(`${API_URL}/${id}`);
            cargarDatos();
        } catch (err) { console.error(err); }
    };

    const estilos = {
        contenedor: { padding: '50px', backgroundColor: '#f3e5f5', minHeight: '100vh', fontFamily: 'Segoe UI' },
        tarjeta: { backgroundColor: 'white', padding: '30px', borderRadius: '20px', boxShadow: '0 8px 16px rgba(0,0,0,0.1)', maxWidth: '900px', margin: '0 auto' },
        titulo: { color: '#7b1fa2', textAlign: 'center' },
        subtitulo: { color: '#9c27b0', textAlign: 'center', marginBottom: '30px' },
        input: { padding: '12px', width: '300px', borderRadius: '8px', border: '2px solid #e1bee7' },
        botonGuardar: { padding: '12px 25px', marginLeft: '10px', backgroundColor: '#ba68c8', color: 'white', border: 'none', borderRadius: '8px', cursor: 'pointer' },
        tabla: { width: '100%', marginTop: '40px', borderCollapse: 'collapse' },
        encabezadoTabla: { backgroundColor: '#ce93d8', color: 'white' },
        celda: { padding: '15px', borderBottom: '1px solid #f3e5f5', textAlign: 'center' },
        botonEliminar: { backgroundColor: '#ef9a9a', color: 'white', border: 'none', padding: '8px 15px', borderRadius: '6px' }
    };

    return (
        <div style={estilos.contenedor}>
            <div style={estilos.tarjeta}>
                <h1 style={estilos.titulo}>Sistema de Gestión - Universitario Japón</h1>
                <h3 style={estilos.subtitulo}>Estudiante: Angela Arcos</h3>
                <div style={{ textAlign: 'center' }}>
                    <input value={nombre} onChange={(e) => setNombre(e.target.value)} placeholder="Nombre del cliente..." style={estilos.input} />
                    <button onClick={guardar} style={estilos.botonGuardar}>Guardar Registro</button>
                </div>
                <table style={estilos.tabla}>
                    <thead>
                        <tr style={estilos.encabezadoTabla}>
                            <th style={estilos.celda}>ID</th>
                            <th style={estilos.celda}>Nombre</th>
                            <th style={estilos.celda}>Acciones</th>
                        </tr>
                    </thead>
                    <tbody>
                        {clientes.length > 0 ? (
                            clientes.map(c => (
                                <tr key={c.id || c.Id}>
                                    <td style={estilos.celda}>{c.id || c.Id}</td>
                                    <td style={estilos.celda}>{c.nombre || c.Nombre}</td>
                                    <td style={estilos.celda}><button onClick={() => eliminar(c.id || c.Id)} style={estilos.botonEliminar}>Eliminar</button></td>
                                </tr>
                            ))
                        ) : (
                            <tr><td colSpan="3" style={estilos.celda}>Conectado al puerto 8080 (Docker)</td></tr>
                        )}
                    </tbody>
                </table>
            </div>
        </div>
    );
}

export default App;