import json
import pika

class RabbitMQProducer:

    def __init__(self):
        # PEGA AQUÍ la URL que copiaste de CloudAMQP (la que empieza con amqps://)
        self.url = "amqps://uwfmfenx:***@capybara.lmq.cloudamqp.com/uwfmfenx"
        
        # Configuramos la conexión usando la URL
        self.params = pika.URLParameters(self.url)
        self.connection = pika.BlockingConnection(self.params)
        self.channel = self.connection.channel()

    def publish(self, queue: str, message: dict):
        # Declaramos la cola para asegurarnos de que exista
        self.channel.queue_declare(queue=queue)

        # Publicamos el mensaje en formato JSON
        self.channel.basic_publish(
            exchange="",
            routing_key=queue,
            body=json.dumps(message)
        )

        print(f"📤 Mensaje enviado a la nube ({queue}): {message}")

    def close(self):
        if self.connection and not self.connection.is_closed:
            self.connection.close()