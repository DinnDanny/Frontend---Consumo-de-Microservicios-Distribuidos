﻿using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.Linq;

namespace app.ArcosDanny.api.Controllers
{
    // 1. Definición del modelo (Esto es lo que faltaba para que compile)
    public class Cliente
    {
        public int Id { get; set; }
        public string Nombre { get; set; }
        public string Apellido { get; set; }
        public int Edad { get; set; }
        public string Direccion { get; set; }
    }

    [ApiController]
    [Route("[controller]")] // La ruta será: https://localhost:7070/Persona
    public class PersonaController : ControllerBase
    {
        private static List<Cliente> clientes = new List<Cliente>
        {
            new Cliente { Id = 1, Nombre = "Danny", Apellido = "Arcos", Edad = 25, Direccion = "Quito" },
            new Cliente { Id = 2, Nombre = "Byron", Apellido = "Cholca", Edad = 35, Direccion = "Guayaquil" }
        };

        [HttpGet]
        public IActionResult GetAll() => Ok(clientes);

        [HttpGet("{id}")]
        public IActionResult GetById(int id)
        {
            var cliente = clientes.FirstOrDefault(c => c.Id == id);
            return cliente == null ? NotFound("No existe") : Ok(cliente);
        }

        [HttpPost]
        public IActionResult Create([FromBody] Cliente nuevo)
        {
            clientes.Add(nuevo);
            // Esto devuelve un 201 Created
            return CreatedAtAction(nameof(GetById), new { id = nuevo.Id }, nuevo);
        }

        [HttpPut("{id}")]
        public IActionResult Update(int id, [FromBody] Cliente actualizado)
        {
            var cliente = clientes.FirstOrDefault(c => c.Id == id);
            if (cliente == null) return NotFound();

            cliente.Nombre = actualizado.Nombre;
            cliente.Apellido = actualizado.Apellido;
            cliente.Edad = actualizado.Edad;
            cliente.Direccion = actualizado.Direccion;

            return Ok(cliente);
        }

        [HttpDelete("{id}")]
        public IActionResult Delete(int id)
        {
            var cliente = clientes.FirstOrDefault(c => c.Id == id);
            if (cliente == null) return NotFound();

            clientes.Remove(cliente);
            return NoContent(); // Devuelve 204 No Content (Éxito al borrar)
        }
    }
}